function getSeqtable(sUrl, postData, divID, formID, cmdstr){

 if(cmdstr !==  undefined )   {   eval( cmdstr ); }
 
 var callback =
 {
   success:function(o){
	if(o.responseText !== undefined){
		var div = document.getElementById(o.argument[0]);
		div.innerHTML = o.responseText;
	}
   },
   failure:function(o){
	//window.alert("Failed to retrieve data from remote server");
	if(o.responseText !== undefined){
		var div = document.getElementById(o.argument[0]);
		div.innerHTML = o.responseText;
	}
   },
   timeout: 40000,
   argument:[divID]
 };
 
 if(postData !== undefined  && postData !== '')
 {
    YAHOO.util.Connect.asyncRequest('POST', sUrl, callback, postData);
 }
 else if(formID !== undefined  && formID !== '')
 {
    var formObject = document.getElementById(formID);
    YAHOO.util.Connect.setForm(formObject);
    YAHOO.util.Connect.asyncRequest('POST', sUrl, callback);    
 }
 else
 {
    YAHOO.util.Connect.asyncRequest('POST', sUrl, callback); 
 }
}
