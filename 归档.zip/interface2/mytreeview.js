function MyTreeView(divId, urlprefix, nodeclick, myurlhead) {

 var tree;
 
 this.loadNodeData=function (node, fnLoadComplete)  {
   var nodeID;
   
   if(fnLoadComplete === undefined ) { nodeID=""; }
   else                              { nodeID = encodeURI(node.data.id); }

   var sUrl = urlprefix + nodeID;
   
   var callback = {
            
      success: function(oResponse) {
         var mynode=oResponse.argument.node;

         var oResults = eval("(" + oResponse.responseText + ")");
         if((oResults.ResultSet) && (oResults.ResultSet.length)) 
         {
            if(YAHOO.lang.isArray(oResults.ResultSet)) 
            {
              for (var i=0, j=oResults.ResultSet.length; i<j; i=i+1) 
              {
			           var tmpnodeobj = oResults.ResultSet[i];
			           if(tmpnodeobj===undefined) continue;
			           var myobj = { label: tmpnodeobj[0], id:tmpnodeobj[1], href:myurlhead+"#"+tmpnodeobj[1]  }; 
                 new YAHOO.widget.TextNode(myobj, mynode, false);
              }
            } 
			      else 
			      {
		           var myobj2 = { label: oResults.ResultSet[0], id:oResults.ResultSet[1], href:myurlhead+"#"+oResults.ResultSet[1] }; 
			         new YAHOO.widget.TextNode(myobj2, mynode, false);
            }
         }

         if(oResponse.argument.fnLoadComplete !== undefined )
         {   oResponse.argument.fnLoadComplete();  }
	       else
  		   {  
  		       tree.draw();
  		       //YAHOO.widget.TreeView.getNode(divId,1).toggle();   
  		   }
      },
                
      failure: function(oResponse) 
      {
         if(oResponse.argument.fnLoadComplete !== undefined )
         { oResponse.argument.fnLoadComplete(); }
	       else
  			 {  tree.draw();  }
      },
                
      argument: {
                    "node": node,
                    "fnLoadComplete": fnLoadComplete
      },
                
      timeout: 10000
     };
            
     YAHOO.util.Connect.asyncRequest('GET', sUrl, callback);
 }; //end of this.loadNodeData

 this.buildTree=function () {
	  tree = new YAHOO.widget.TreeView(divId);
	  tree.setDynamicLoad(this.loadNodeData, 1);
    var root = tree.getRoot();
	  this.loadNodeData(root);
    tree.draw();
    tree.subscribe("labelClick", nodeclick); 
 }; //end of this.buildTree

 this.buildTree();
}
